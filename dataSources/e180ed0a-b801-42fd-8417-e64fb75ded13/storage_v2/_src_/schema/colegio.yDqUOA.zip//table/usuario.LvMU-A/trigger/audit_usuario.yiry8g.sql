create definer = root@localhost trigger audit_usuario
    after insert
    on usuario
    for each row
BEGIN
    INSERT INTO Usuario_Auditoria (id_usuario, accion, fecha) VALUES (NEW.id_usuario, 'INSERT', NOW());
END;

