create definer = root@localhost trigger check_fecha_nacimiento
    before insert
    on usuario
    for each row
BEGIN
    IF NEW.fecha_nacimiento > CURDATE() THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La fecha de nacimiento no puede ser futura.';
    END IF;
END;

