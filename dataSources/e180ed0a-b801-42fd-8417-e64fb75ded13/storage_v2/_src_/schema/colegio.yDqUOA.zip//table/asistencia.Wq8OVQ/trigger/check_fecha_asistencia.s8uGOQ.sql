create definer = root@localhost trigger check_fecha_asistencia
    before insert
    on asistencia
    for each row
BEGIN
    IF NEW.fecha > CURDATE() THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La fecha de asistencia no puede ser futura.';
    END IF;
END;

