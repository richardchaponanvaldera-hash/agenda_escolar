create definer = `mariadb.sys`@localhost view host_summary as
select if(`performance_schema`.`accounts`.`HOST` is null, 'background',
          `performance_schema`.`accounts`.`HOST`)                                                AS `host`,
       sum(`stmt`.`total`)                                                                       AS `statements`,
       format_pico_time(sum(`stmt`.`total_latency`))                                             AS `statement_latency`,
       format_pico_time(ifnull(sum(`stmt`.`total_latency`) / nullif(sum(`stmt`.`total`), 0),
                               0))                                                               AS `statement_avg_latency`,
       sum(`stmt`.`full_scans`)                                                                  AS `table_scans`,
       sum(`io`.`ios`)                                                                           AS `file_ios`,
       format_pico_time(sum(`io`.`io_latency`))                                                  AS `file_io_latency`,
       sum(`performance_schema`.`accounts`.`CURRENT_CONNECTIONS`)                                AS `current_connections`,
       sum(`performance_schema`.`accounts`.`TOTAL_CONNECTIONS`)                                  AS `total_connections`,
       count(distinct `performance_schema`.`accounts`.`USER`)                                    AS `unique_users`,
       `sys`.`format_bytes`(sum(`mem`.`current_allocated`))                                      AS `current_memory`,
       `sys`.`format_bytes`(sum(`mem`.`total_allocated`))                                        AS `total_memory_allocated`
from (((`performance_schema`.`accounts` join `sys`.`x$host_summary_by_statement_latency` `stmt`
        on (`performance_schema`.`accounts`.`HOST` = `stmt`.`host`)) join `sys`.`x$host_summary_by_file_io` `io`
       on (`performance_schema`.`accounts`.`HOST` = `io`.`host`)) join `sys`.`x$memory_by_host_by_current_bytes` `mem`
      on (`performance_schema`.`accounts`.`HOST` = `mem`.`host`))
group by if(`performance_schema`.`accounts`.`HOST` is null, 'background', `performance_schema`.`accounts`.`HOST`);

