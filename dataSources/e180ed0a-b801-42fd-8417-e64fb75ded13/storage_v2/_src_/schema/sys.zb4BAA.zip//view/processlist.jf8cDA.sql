create definer = `mariadb.sys`@localhost view processlist as
select `pps`.`THREAD_ID`                                                                                           AS `thd_id`,
       `pps`.`PROCESSLIST_ID`                                                                                      AS `conn_id`,
       if(`pps`.`NAME` = 'thread/sql/one_connection', concat(`pps`.`PROCESSLIST_USER`, '@', `pps`.`PROCESSLIST_HOST`),
          replace(`pps`.`NAME`, 'thread/', ''))                                                                    AS `user`,
       `pps`.`PROCESSLIST_DB`                                                                                      AS `db`,
       `pps`.`PROCESSLIST_COMMAND`                                                                                 AS `command`,
       `pps`.`PROCESSLIST_STATE`                                                                                   AS `state`,
       `pps`.`PROCESSLIST_TIME`                                                                                    AS `time`,
       `sys`.`format_statement`(`pps`.`PROCESSLIST_INFO`)                                                          AS `current_statement`,
       if(`esc`.`END_EVENT_ID` is null, format_pico_time(`esc`.`TIMER_WAIT`),
          NULL)                                                                                                    AS `statement_latency`,
       if(`esc`.`END_EVENT_ID` is null, round(100 * (`estc`.`WORK_COMPLETED` / `estc`.`WORK_ESTIMATED`), 2),
          NULL)                                                                                                    AS `progress`,
       format_pico_time(`esc`.`LOCK_TIME`)                                                                         AS `lock_latency`,
       `esc`.`ROWS_EXAMINED`                                                                                       AS `rows_examined`,
       `esc`.`ROWS_SENT`                                                                                           AS `rows_sent`,
       `esc`.`ROWS_AFFECTED`                                                                                       AS `rows_affected`,
       `esc`.`CREATED_TMP_TABLES`                                                                                  AS `tmp_tables`,
       `esc`.`CREATED_TMP_DISK_TABLES`                                                                             AS `tmp_disk_tables`,
       if(`esc`.`NO_GOOD_INDEX_USED` > 0 or `esc`.`NO_INDEX_USED` > 0, 'YES',
          'NO')                                                                                                    AS `full_scan`,
       if(`esc`.`END_EVENT_ID` is not null, `sys`.`format_statement`(`esc`.`SQL_TEXT`),
          NULL)                                                                                                    AS `last_statement`,
       if(`esc`.`END_EVENT_ID` is not null, format_pico_time(`esc`.`TIMER_WAIT`),
          NULL)                                                                                                    AS `last_statement_latency`,
       `sys`.`format_bytes`(`mem`.`current_allocated`)                                                             AS `current_memory`,
       `ewc`.`EVENT_NAME`                                                                                          AS `last_wait`,
       if(`ewc`.`END_EVENT_ID` is null and `ewc`.`EVENT_NAME` is not null, 'Still Waiting',
          format_pico_time(`ewc`.`TIMER_WAIT`))                                                                    AS `last_wait_latency`,
       `ewc`.`SOURCE`                                                                                              AS `source`,
       format_pico_time(`etc`.`TIMER_WAIT`)                                                                        AS `trx_latency`,
       `etc`.`STATE`                                                                                               AS `trx_state`,
       `etc`.`AUTOCOMMIT`                                                                                          AS `trx_autocommit`,
       `conattr_pid`.`ATTR_VALUE`                                                                                  AS `pid`,
       `conattr_progname`.`ATTR_VALUE`                                                                             AS `program_name`
from (((((((`performance_schema`.`threads` `pps` left join `performance_schema`.`events_waits_current` `ewc`
            on (`pps`.`THREAD_ID` = `ewc`.`THREAD_ID`)) left join `performance_schema`.`events_stages_current` `estc`
           on (`pps`.`THREAD_ID` = `estc`.`THREAD_ID`)) left join `performance_schema`.`events_statements_current` `esc`
          on (`pps`.`THREAD_ID` = `esc`.`THREAD_ID`)) left join `performance_schema`.`events_transactions_current` `etc`
         on (`pps`.`THREAD_ID` = `etc`.`THREAD_ID`)) left join `sys`.`x$memory_by_thread_by_current_bytes` `mem`
        on (`pps`.`THREAD_ID` = `mem`.`thread_id`)) left join `performance_schema`.`session_connect_attrs` `conattr_pid`
       on (`conattr_pid`.`PROCESSLIST_ID` = `pps`.`PROCESSLIST_ID` and `conattr_pid`.`ATTR_NAME` =
                                                                       '_pid')) left join `performance_schema`.`session_connect_attrs` `conattr_progname`
      on (`conattr_progname`.`PROCESSLIST_ID` = `pps`.`PROCESSLIST_ID` and
          `conattr_progname`.`ATTR_NAME` = 'program_name'))
order by `pps`.`PROCESSLIST_TIME` desc,
         if(`ewc`.`END_EVENT_ID` is null and `ewc`.`EVENT_NAME` is not null, 'Still Waiting',
            format_pico_time(`ewc`.`TIMER_WAIT`)) desc;

-- comment on column processlist.thd_id not supported: A unique thread identifier.

-- comment on column processlist.conn_id not supported: The PROCESSLIST.ID value for threads displayed in the INFORMATION_SCHEMA.PROCESSLIST table, or 0 for background threads. Also corresponds with the CONNECTION_ID() return value for the thread.

-- comment on column processlist.db not supported: Thread's default database, or NULL if none exists.

-- comment on column processlist.command not supported: Type of command executed by the thread. These correspond to the the COM_xxx client/server protocol commands, and the Com_xxx status variables. See Thread Command Values.

-- comment on column processlist.state not supported: Action, event or state indicating what the thread is doing.

-- comment on column processlist.time not supported: Time in seconds the thread has been in its current state.

-- comment on column processlist.rows_examined not supported: Number of rows read during the statement's execution.

-- comment on column processlist.rows_sent not supported: Number of rows returned.

-- comment on column processlist.rows_affected not supported: Number of rows affected the statement affected.

-- comment on column processlist.tmp_tables not supported: Number of temp tables created by the statement.

-- comment on column processlist.tmp_disk_tables not supported: Number of on-disk temp tables created by the statement.

-- comment on column processlist.last_wait not supported: Event instrument name and a NAME from the setup_instruments table

-- comment on column processlist.source not supported: Name and line number of the source file containing the instrumented code that produced the event.

-- comment on column processlist.trx_state not supported: The current transaction state. The value is ACTIVE (after START TRANSACTION or BEGIN), COMMITTED (after COMMIT), or ROLLED BACK (after ROLLBACK).

-- comment on column processlist.trx_autocommit not supported: Whether autcommit mode was enabled when the transaction started.

-- comment on column processlist.pid not supported: Attribute value.

-- comment on column processlist.program_name not supported: Attribute value.

