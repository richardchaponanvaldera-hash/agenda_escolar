create definer = `mariadb.sys`@localhost view x$waits_by_user_by_latency as
select if(`performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER` is null, 'background',
          `performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER`)       AS `user`,
       `performance_schema`.`events_waits_summary_by_user_by_event_name`.`EVENT_NAME`     AS `event`,
       `performance_schema`.`events_waits_summary_by_user_by_event_name`.`COUNT_STAR`     AS `total`,
       `performance_schema`.`events_waits_summary_by_user_by_event_name`.`SUM_TIMER_WAIT` AS `total_latency`,
       `performance_schema`.`events_waits_summary_by_user_by_event_name`.`AVG_TIMER_WAIT` AS `avg_latency`,
       `performance_schema`.`events_waits_summary_by_user_by_event_name`.`MAX_TIMER_WAIT` AS `max_latency`
from `performance_schema`.`events_waits_summary_by_user_by_event_name`
where `performance_schema`.`events_waits_summary_by_user_by_event_name`.`EVENT_NAME` <> 'idle'
  and `performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER` is not null
  and `performance_schema`.`events_waits_summary_by_user_by_event_name`.`SUM_TIMER_WAIT` > 0
order by if(`performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER` is null, 'background',
            `performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER`),
         `performance_schema`.`events_waits_summary_by_user_by_event_name`.`SUM_TIMER_WAIT` desc;

-- comment on column x$waits_by_user_by_latency.event not supported: Event name. Used together with USER for grouping events.

-- comment on column x$waits_by_user_by_latency.total not supported: Number of summarized events

-- comment on column x$waits_by_user_by_latency.total_latency not supported: Total wait time of the summarized events that are timed.

-- comment on column x$waits_by_user_by_latency.avg_latency not supported: Average wait time of the summarized events that are timed.

-- comment on column x$waits_by_user_by_latency.max_latency not supported: Maximum wait time of the summarized events that are timed.

