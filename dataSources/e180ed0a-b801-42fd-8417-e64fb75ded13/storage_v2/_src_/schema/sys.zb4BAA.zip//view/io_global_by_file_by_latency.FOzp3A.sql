create definer = `mariadb.sys`@localhost view io_global_by_file_by_latency as
select `sys`.`format_path`(`performance_schema`.`file_summary_by_instance`.`FILE_NAME`)    AS `file`,
       `performance_schema`.`file_summary_by_instance`.`COUNT_STAR`                        AS `total`,
       format_pico_time(`performance_schema`.`file_summary_by_instance`.`SUM_TIMER_WAIT`)  AS `total_latency`,
       `performance_schema`.`file_summary_by_instance`.`COUNT_READ`                        AS `count_read`,
       format_pico_time(`performance_schema`.`file_summary_by_instance`.`SUM_TIMER_READ`)  AS `read_latency`,
       `performance_schema`.`file_summary_by_instance`.`COUNT_WRITE`                       AS `count_write`,
       format_pico_time(`performance_schema`.`file_summary_by_instance`.`SUM_TIMER_WRITE`) AS `write_latency`,
       `performance_schema`.`file_summary_by_instance`.`COUNT_MISC`                        AS `count_misc`,
       format_pico_time(`performance_schema`.`file_summary_by_instance`.`SUM_TIMER_MISC`)  AS `misc_latency`
from `performance_schema`.`file_summary_by_instance`
order by `performance_schema`.`file_summary_by_instance`.`SUM_TIMER_WAIT` desc;

-- comment on column io_global_by_file_by_latency.total not supported: Number of summarized events

-- comment on column io_global_by_file_by_latency.count_read not supported: Number of all read operations, including FGETS, FGETC, FREAD, and READ.

-- comment on column io_global_by_file_by_latency.count_write not supported: Number of all write operations, including FPUTS, FPUTC, FPRINTF, VFPRINTF, FWRITE, and PWRITE.

-- comment on column io_global_by_file_by_latency.count_misc not supported: Number of all miscellaneous operations not counted above, including CREATE, DELETE, OPEN, CLOSE, STREAM_OPEN, STREAM_CLOSE, SEEK, TELL, FLUSH, STAT, FSTAT, CHSIZE, RENAME, and SYNC.

