create definer = `mariadb.sys`@localhost view x$schema_table_statistics as
select `pst`.`OBJECT_SCHEMA`              AS `table_schema`,
       `pst`.`OBJECT_NAME`                AS `table_name`,
       `pst`.`SUM_TIMER_WAIT`             AS `total_latency`,
       `pst`.`COUNT_FETCH`                AS `rows_fetched`,
       `pst`.`SUM_TIMER_FETCH`            AS `fetch_latency`,
       `pst`.`COUNT_INSERT`               AS `rows_inserted`,
       `pst`.`SUM_TIMER_INSERT`           AS `insert_latency`,
       `pst`.`COUNT_UPDATE`               AS `rows_updated`,
       `pst`.`SUM_TIMER_UPDATE`           AS `update_latency`,
       `pst`.`COUNT_DELETE`               AS `rows_deleted`,
       `pst`.`SUM_TIMER_DELETE`           AS `delete_latency`,
       `fsbi`.`count_read`                AS `io_read_requests`,
       `fsbi`.`sum_number_of_bytes_read`  AS `io_read`,
       `fsbi`.`sum_timer_read`            AS `io_read_latency`,
       `fsbi`.`count_write`               AS `io_write_requests`,
       `fsbi`.`sum_number_of_bytes_write` AS `io_write`,
       `fsbi`.`sum_timer_write`           AS `io_write_latency`,
       `fsbi`.`count_misc`                AS `io_misc_requests`,
       `fsbi`.`sum_timer_misc`            AS `io_misc_latency`
from (`performance_schema`.`table_io_waits_summary_by_table` `pst` left join `sys`.`x$ps_schema_table_statistics_io` `fsbi`
      on (`pst`.`OBJECT_SCHEMA` = `fsbi`.`table_schema` and `pst`.`OBJECT_NAME` = `fsbi`.`table_name`))
order by `pst`.`SUM_TIMER_WAIT` desc;

-- comment on column x$schema_table_statistics.table_schema not supported: Schema name.

-- comment on column x$schema_table_statistics.table_name not supported: Table name.

-- comment on column x$schema_table_statistics.total_latency not supported: Total wait time of the summarized events that are timed.

-- comment on column x$schema_table_statistics.rows_fetched not supported: Number of all fetch operations.

-- comment on column x$schema_table_statistics.fetch_latency not supported: Total wait time of all fetch operations that are timed.

-- comment on column x$schema_table_statistics.rows_inserted not supported: Number of all insert operations.

-- comment on column x$schema_table_statistics.insert_latency not supported: Total wait time of all insert operations that are timed.

-- comment on column x$schema_table_statistics.rows_updated not supported: Number of all update operations.

-- comment on column x$schema_table_statistics.update_latency not supported: Total wait time of all update operations that are timed.

-- comment on column x$schema_table_statistics.rows_deleted not supported: Number of all delete operations.

-- comment on column x$schema_table_statistics.delete_latency not supported: Total wait time of all delete operations that are timed.

