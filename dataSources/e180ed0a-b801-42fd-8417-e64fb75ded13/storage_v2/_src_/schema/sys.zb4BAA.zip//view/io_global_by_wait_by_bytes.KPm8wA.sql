create definer = `mariadb.sys`@localhost view io_global_by_wait_by_bytes as
select substring_index(`performance_schema`.`file_summary_by_event_name`.`EVENT_NAME`, '/', -2)                    AS `event_name`,
       `performance_schema`.`file_summary_by_event_name`.`COUNT_STAR`                                              AS `total`,
       format_pico_time(`performance_schema`.`file_summary_by_event_name`.`SUM_TIMER_WAIT`)                        AS `total_latency`,
       format_pico_time(`performance_schema`.`file_summary_by_event_name`.`MIN_TIMER_WAIT`)                        AS `min_latency`,
       format_pico_time(`performance_schema`.`file_summary_by_event_name`.`AVG_TIMER_WAIT`)                        AS `avg_latency`,
       format_pico_time(`performance_schema`.`file_summary_by_event_name`.`MAX_TIMER_WAIT`)                        AS `max_latency`,
       `performance_schema`.`file_summary_by_event_name`.`COUNT_READ`                                              AS `count_read`,
       `sys`.`format_bytes`(`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_READ`)          AS `total_read`,
       `sys`.`format_bytes`(ifnull(`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_READ` /
                                   nullif(`performance_schema`.`file_summary_by_event_name`.`COUNT_READ`, 0),
                                   0))                                                                             AS `avg_read`,
       `performance_schema`.`file_summary_by_event_name`.`COUNT_WRITE`                                             AS `count_write`,
       `sys`.`format_bytes`(`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_WRITE`)         AS `total_written`,
       `sys`.`format_bytes`(ifnull(`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_WRITE` /
                                   nullif(`performance_schema`.`file_summary_by_event_name`.`COUNT_WRITE`, 0),
                                   0))                                                                             AS `avg_written`,
       `sys`.`format_bytes`(`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_WRITE` +
                            `performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_READ`)          AS `total_requested`
from `performance_schema`.`file_summary_by_event_name`
where `performance_schema`.`file_summary_by_event_name`.`EVENT_NAME` like 'wait/io/file/%'
  and `performance_schema`.`file_summary_by_event_name`.`COUNT_STAR` > 0
order by `performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_WRITE` +
         `performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_READ` desc;

-- comment on column io_global_by_wait_by_bytes.total not supported: Number of summarized events

-- comment on column io_global_by_wait_by_bytes.count_read not supported: Number of all read operations, including FGETS, FGETC, FREAD, and READ.

-- comment on column io_global_by_wait_by_bytes.count_write not supported: Number of all write operations, including FPUTS, FPUTC, FPRINTF, VFPRINTF, FWRITE, and PWRITE.

