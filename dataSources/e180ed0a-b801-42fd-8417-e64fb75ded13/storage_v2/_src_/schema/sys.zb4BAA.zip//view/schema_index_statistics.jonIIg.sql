create definer = `mariadb.sys`@localhost view schema_index_statistics as
select `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_SCHEMA`                      AS `table_schema`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_NAME`                        AS `table_name`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME`                         AS `index_name`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_FETCH`                        AS `rows_selected`,
       format_pico_time(`performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_FETCH`)  AS `select_latency`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_INSERT`                       AS `rows_inserted`,
       format_pico_time(`performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_INSERT`) AS `insert_latency`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_UPDATE`                       AS `rows_updated`,
       format_pico_time(`performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_UPDATE`) AS `update_latency`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_DELETE`                       AS `rows_deleted`,
       format_pico_time(`performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_INSERT`) AS `delete_latency`
from `performance_schema`.`table_io_waits_summary_by_index_usage`
where `performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME` is not null
order by `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_WAIT` desc;

-- comment on column schema_index_statistics.table_schema not supported: Schema name.

-- comment on column schema_index_statistics.table_name not supported: Table name.

-- comment on column schema_index_statistics.index_name not supported: Index name, or PRIMARY for the primary index, NULL for no index (inserts are counted in this case).

-- comment on column schema_index_statistics.rows_selected not supported: Number of all fetch operations.

-- comment on column schema_index_statistics.rows_inserted not supported: Number of all insert operations.

-- comment on column schema_index_statistics.rows_updated not supported: Number of all update operations.

-- comment on column schema_index_statistics.rows_deleted not supported: Number of all delete operations.

