create definer = `mariadb.sys`@localhost view x$statements_with_sorting as
select `performance_schema`.`events_statements_summary_by_digest`.`DIGEST_TEXT`                                AS `query`,
       `performance_schema`.`events_statements_summary_by_digest`.`SCHEMA_NAME`                                AS `db`,
       `performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`                                 AS `exec_count`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_TIMER_WAIT`                             AS `total_latency`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_MERGE_PASSES`                      AS `sort_merge_passes`,
       round(ifnull(`performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_MERGE_PASSES` /
                    nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`, 0), 0),
             0)                                                                                                AS `avg_sort_merges`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_SCAN`                              AS `sorts_using_scans`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_RANGE`                             AS `sort_using_range`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_ROWS`                              AS `rows_sorted`,
       round(ifnull(`performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_ROWS` /
                    nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`, 0), 0),
             0)                                                                                                AS `avg_rows_sorted`,
       `performance_schema`.`events_statements_summary_by_digest`.`FIRST_SEEN`                                 AS `first_seen`,
       `performance_schema`.`events_statements_summary_by_digest`.`LAST_SEEN`                                  AS `last_seen`,
       `performance_schema`.`events_statements_summary_by_digest`.`DIGEST`                                     AS `digest`
from `performance_schema`.`events_statements_summary_by_digest`
where `performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_ROWS` > 0
order by `performance_schema`.`events_statements_summary_by_digest`.`SUM_TIMER_WAIT` desc;

-- comment on column x$statements_with_sorting.query not supported: The unhashed form of the digest.

-- comment on column x$statements_with_sorting.db not supported: Database name. Records are summarised together with DIGEST.

-- comment on column x$statements_with_sorting.exec_count not supported: Number of summarized events

-- comment on column x$statements_with_sorting.total_latency not supported: Total wait time of the summarized events that are timed.

-- comment on column x$statements_with_sorting.sort_merge_passes not supported: Sum of the SORT_MERGE_PASSES column in the events_statements_current table.

-- comment on column x$statements_with_sorting.sorts_using_scans not supported: Sum of the SORT_SCAN column in the events_statements_current table.

-- comment on column x$statements_with_sorting.sort_using_range not supported: Sum of the SORT_RANGE column in the events_statements_current table.

-- comment on column x$statements_with_sorting.rows_sorted not supported: Sum of the SORT_ROWS column in the events_statements_current table.

-- comment on column x$statements_with_sorting.first_seen not supported: Time at which the digest was first seen.

-- comment on column x$statements_with_sorting.last_seen not supported: Time at which the digest was most recently seen.

-- comment on column x$statements_with_sorting.digest not supported: Performance Schema digest. Records are summarised together with SCHEMA NAME.

