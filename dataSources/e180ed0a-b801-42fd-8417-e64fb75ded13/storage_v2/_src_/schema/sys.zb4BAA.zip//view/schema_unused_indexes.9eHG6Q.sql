create definer = `mariadb.sys`@localhost view schema_unused_indexes as
select `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_SCHEMA` AS `object_schema`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_NAME`   AS `object_name`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME`    AS `index_name`
from `performance_schema`.`table_io_waits_summary_by_index_usage`
where `performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME` is not null
  and `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_STAR` = 0
  and `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_SCHEMA` <> 'mysql'
  and `performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME` <> 'PRIMARY'
order by `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_SCHEMA`,
         `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_NAME`;

-- comment on column schema_unused_indexes.object_schema not supported: Schema name.

-- comment on column schema_unused_indexes.object_name not supported: Table name.

-- comment on column schema_unused_indexes.index_name not supported: Index name, or PRIMARY for the primary index, NULL for no index (inserts are counted in this case).

