create definer = `mariadb.sys`@localhost view x$ps_digest_95th_percentile_by_avg_us as
select `s2`.`avg_us`                                                                                           AS `avg_us`,
       ifnull(sum(`s1`.`cnt`) /
              nullif((select count(0) from `performance_schema`.`events_statements_summary_by_digest`), 0),
              0)                                                                                               AS `percentile`
from (`sys`.`x$ps_digest_avg_latency_distribution` `s1` join `sys`.`x$ps_digest_avg_latency_distribution` `s2`
      on (`s1`.`avg_us` <= `s2`.`avg_us`))
group by `s2`.`avg_us`
having ifnull(sum(`s1`.`cnt`) /
              nullif((select count(0) from `performance_schema`.`events_statements_summary_by_digest`), 0), 0) > 0.95
order by ifnull(sum(`s1`.`cnt`) /
                nullif((select count(0) from `performance_schema`.`events_statements_summary_by_digest`), 0), 0)
limit 1;

