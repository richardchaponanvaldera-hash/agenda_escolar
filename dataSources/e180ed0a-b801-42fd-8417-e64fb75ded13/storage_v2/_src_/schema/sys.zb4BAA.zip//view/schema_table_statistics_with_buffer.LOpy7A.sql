create definer = `mariadb.sys`@localhost view schema_table_statistics_with_buffer as
select `pst`.`OBJECT_SCHEMA`                                    AS `table_schema`,
       `pst`.`OBJECT_NAME`                                      AS `table_name`,
       `pst`.`COUNT_FETCH`                                      AS `rows_fetched`,
       format_pico_time(`pst`.`SUM_TIMER_FETCH`)                AS `fetch_latency`,
       `pst`.`COUNT_INSERT`                                     AS `rows_inserted`,
       format_pico_time(`pst`.`SUM_TIMER_INSERT`)               AS `insert_latency`,
       `pst`.`COUNT_UPDATE`                                     AS `rows_updated`,
       format_pico_time(`pst`.`SUM_TIMER_UPDATE`)               AS `update_latency`,
       `pst`.`COUNT_DELETE`                                     AS `rows_deleted`,
       format_pico_time(`pst`.`SUM_TIMER_DELETE`)               AS `delete_latency`,
       `fsbi`.`count_read`                                      AS `io_read_requests`,
       `sys`.`format_bytes`(`fsbi`.`sum_number_of_bytes_read`)  AS `io_read`,
       format_pico_time(`fsbi`.`sum_timer_read`)                AS `io_read_latency`,
       `fsbi`.`count_write`                                     AS `io_write_requests`,
       `sys`.`format_bytes`(`fsbi`.`sum_number_of_bytes_write`) AS `io_write`,
       format_pico_time(`fsbi`.`sum_timer_write`)               AS `io_write_latency`,
       `fsbi`.`count_misc`                                      AS `io_misc_requests`,
       format_pico_time(`fsbi`.`sum_timer_misc`)                AS `io_misc_latency`,
       `sys`.`format_bytes`(`ibp`.`allocated`)                  AS `innodb_buffer_allocated`,
       `sys`.`format_bytes`(`ibp`.`data`)                       AS `innodb_buffer_data`,
       `sys`.`format_bytes`(`ibp`.`allocated` - `ibp`.`data`)   AS `innodb_buffer_free`,
       `ibp`.`pages`                                            AS `innodb_buffer_pages`,
       `ibp`.`pages_hashed`                                     AS `innodb_buffer_pages_hashed`,
       `ibp`.`pages_old`                                        AS `innodb_buffer_pages_old`,
       `ibp`.`rows_cached`                                      AS `innodb_buffer_rows_cached`
from ((`performance_schema`.`table_io_waits_summary_by_table` `pst` left join `sys`.`x$ps_schema_table_statistics_io` `fsbi`
       on (`pst`.`OBJECT_SCHEMA` = `fsbi`.`table_schema` and
           `pst`.`OBJECT_NAME` = `fsbi`.`table_name`)) left join `sys`.`x$innodb_buffer_stats_by_table` `ibp`
      on (`pst`.`OBJECT_SCHEMA` = `ibp`.`object_schema` and `pst`.`OBJECT_NAME` = `ibp`.`object_name`))
order by `pst`.`SUM_TIMER_WAIT` desc;

-- comment on column schema_table_statistics_with_buffer.table_schema not supported: Schema name.

-- comment on column schema_table_statistics_with_buffer.table_name not supported: Table name.

-- comment on column schema_table_statistics_with_buffer.rows_fetched not supported: Number of all fetch operations.

-- comment on column schema_table_statistics_with_buffer.rows_inserted not supported: Number of all insert operations.

-- comment on column schema_table_statistics_with_buffer.rows_updated not supported: Number of all update operations.

-- comment on column schema_table_statistics_with_buffer.rows_deleted not supported: Number of all delete operations.

