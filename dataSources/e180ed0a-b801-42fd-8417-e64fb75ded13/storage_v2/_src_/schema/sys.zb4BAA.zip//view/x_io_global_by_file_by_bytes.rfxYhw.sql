create definer = `mariadb.sys`@localhost view x$io_global_by_file_by_bytes as
select `performance_schema`.`file_summary_by_instance`.`FILE_NAME`                                              AS `file`,
       `performance_schema`.`file_summary_by_instance`.`COUNT_READ`                                             AS `count_read`,
       `performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_READ`                               AS `total_read`,
       ifnull(`performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_READ` /
              nullif(`performance_schema`.`file_summary_by_instance`.`COUNT_READ`, 0),
              0)                                                                                                AS `avg_read`,
       `performance_schema`.`file_summary_by_instance`.`COUNT_WRITE`                                            AS `count_write`,
       `performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_WRITE`                              AS `total_written`,
       ifnull(`performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_WRITE` /
              nullif(`performance_schema`.`file_summary_by_instance`.`COUNT_WRITE`, 0),
              0.00)                                                                                             AS `avg_write`,
       `performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_READ` +
       `performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_WRITE`                              AS `total`,
       ifnull(round(100 - `performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_READ` / nullif(
               `performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_READ` +
               `performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_WRITE`, 0) * 100, 2),
              0.00)                                                                                             AS `write_pct`
from `performance_schema`.`file_summary_by_instance`
order by `performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_READ` +
         `performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_WRITE` desc;

-- comment on column x$io_global_by_file_by_bytes.file not supported: File name.

-- comment on column x$io_global_by_file_by_bytes.count_read not supported: Number of all read operations, including FGETS, FGETC, FREAD, and READ.

-- comment on column x$io_global_by_file_by_bytes.total_read not supported: Bytes read by read operations.

-- comment on column x$io_global_by_file_by_bytes.count_write not supported: Number of all write operations, including FPUTS, FPUTC, FPRINTF, VFPRINTF, FWRITE, and PWRITE.

-- comment on column x$io_global_by_file_by_bytes.total_written not supported: Bytes written by write operations.

