create definer = `mariadb.sys`@localhost view x$user_summary_by_stages as
select if(`performance_schema`.`events_stages_summary_by_user_by_event_name`.`USER` is null, 'background',
          `performance_schema`.`events_stages_summary_by_user_by_event_name`.`USER`)       AS `user`,
       `performance_schema`.`events_stages_summary_by_user_by_event_name`.`EVENT_NAME`     AS `event_name`,
       `performance_schema`.`events_stages_summary_by_user_by_event_name`.`COUNT_STAR`     AS `total`,
       `performance_schema`.`events_stages_summary_by_user_by_event_name`.`SUM_TIMER_WAIT` AS `total_latency`,
       `performance_schema`.`events_stages_summary_by_user_by_event_name`.`AVG_TIMER_WAIT` AS `avg_latency`
from `performance_schema`.`events_stages_summary_by_user_by_event_name`
where `performance_schema`.`events_stages_summary_by_user_by_event_name`.`SUM_TIMER_WAIT` <> 0
order by if(`performance_schema`.`events_stages_summary_by_user_by_event_name`.`USER` is null, 'background',
            `performance_schema`.`events_stages_summary_by_user_by_event_name`.`USER`),
         `performance_schema`.`events_stages_summary_by_user_by_event_name`.`SUM_TIMER_WAIT` desc;

-- comment on column x$user_summary_by_stages.event_name not supported: Event name. Used together with USER for grouping events.

-- comment on column x$user_summary_by_stages.total not supported: Number of summarized events, which includes all timed and untimed events.

-- comment on column x$user_summary_by_stages.total_latency not supported: Total wait time of the timed summarized events.

-- comment on column x$user_summary_by_stages.avg_latency not supported: Average wait time of the timed summarized events.

