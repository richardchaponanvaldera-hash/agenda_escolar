create definer = `mariadb.sys`@localhost view x$user_summary_by_file_io_type as
select if(`performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER` is null, 'background',
          `performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER`)       AS `user`,
       `performance_schema`.`events_waits_summary_by_user_by_event_name`.`EVENT_NAME`     AS `event_name`,
       `performance_schema`.`events_waits_summary_by_user_by_event_name`.`COUNT_STAR`     AS `total`,
       `performance_schema`.`events_waits_summary_by_user_by_event_name`.`SUM_TIMER_WAIT` AS `latency`,
       `performance_schema`.`events_waits_summary_by_user_by_event_name`.`MAX_TIMER_WAIT` AS `max_latency`
from `performance_schema`.`events_waits_summary_by_user_by_event_name`
where `performance_schema`.`events_waits_summary_by_user_by_event_name`.`EVENT_NAME` like 'wait/io/file%'
  and `performance_schema`.`events_waits_summary_by_user_by_event_name`.`COUNT_STAR` > 0
order by if(`performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER` is null, 'background',
            `performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER`),
         `performance_schema`.`events_waits_summary_by_user_by_event_name`.`SUM_TIMER_WAIT` desc;

-- comment on column x$user_summary_by_file_io_type.event_name not supported: Event name. Used together with USER for grouping events.

-- comment on column x$user_summary_by_file_io_type.total not supported: Number of summarized events

-- comment on column x$user_summary_by_file_io_type.latency not supported: Total wait time of the summarized events that are timed.

-- comment on column x$user_summary_by_file_io_type.max_latency not supported: Maximum wait time of the summarized events that are timed.

