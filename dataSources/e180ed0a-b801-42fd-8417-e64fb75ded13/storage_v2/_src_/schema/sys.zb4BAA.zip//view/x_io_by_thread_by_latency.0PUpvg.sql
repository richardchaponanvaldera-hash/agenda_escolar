create definer = `mariadb.sys`@localhost view x$io_by_thread_by_latency as
select if(`performance_schema`.`threads`.`PROCESSLIST_ID` is null,
          substring_index(`performance_schema`.`threads`.`NAME`, '/', -1),
          concat(`performance_schema`.`threads`.`PROCESSLIST_USER`, '@',
                 `performance_schema`.`threads`.`PROCESSLIST_HOST`))                             AS `user`,
       sum(`performance_schema`.`events_waits_summary_by_thread_by_event_name`.`COUNT_STAR`)     AS `total`,
       sum(`performance_schema`.`events_waits_summary_by_thread_by_event_name`.`SUM_TIMER_WAIT`) AS `total_latency`,
       min(`performance_schema`.`events_waits_summary_by_thread_by_event_name`.`MIN_TIMER_WAIT`) AS `min_latency`,
       avg(`performance_schema`.`events_waits_summary_by_thread_by_event_name`.`AVG_TIMER_WAIT`) AS `avg_latency`,
       max(`performance_schema`.`events_waits_summary_by_thread_by_event_name`.`MAX_TIMER_WAIT`) AS `max_latency`,
       `performance_schema`.`events_waits_summary_by_thread_by_event_name`.`THREAD_ID`           AS `thread_id`,
       `performance_schema`.`threads`.`PROCESSLIST_ID`                                           AS `processlist_id`
from (`performance_schema`.`events_waits_summary_by_thread_by_event_name` left join `performance_schema`.`threads`
      on (`performance_schema`.`events_waits_summary_by_thread_by_event_name`.`THREAD_ID` =
          `performance_schema`.`threads`.`THREAD_ID`))
where `performance_schema`.`events_waits_summary_by_thread_by_event_name`.`EVENT_NAME` like 'wait/io/file/%'
  and `performance_schema`.`events_waits_summary_by_thread_by_event_name`.`SUM_TIMER_WAIT` > 0
group by `performance_schema`.`events_waits_summary_by_thread_by_event_name`.`THREAD_ID`,
         `performance_schema`.`threads`.`PROCESSLIST_ID`,
         if(`performance_schema`.`threads`.`PROCESSLIST_ID` is null,
            substring_index(`performance_schema`.`threads`.`NAME`, '/', -1),
            concat(`performance_schema`.`threads`.`PROCESSLIST_USER`, '@',
                   `performance_schema`.`threads`.`PROCESSLIST_HOST`))
order by sum(`performance_schema`.`events_waits_summary_by_thread_by_event_name`.`SUM_TIMER_WAIT`) desc;

-- comment on column x$io_by_thread_by_latency.min_latency not supported: Minimum wait time of the summarized events that are timed.

-- comment on column x$io_by_thread_by_latency.max_latency not supported: Maximum wait time of the summarized events that are timed.

-- comment on column x$io_by_thread_by_latency.thread_id not supported: Thread associated with the event. Together with EVENT_NAME uniquely identifies the row.

-- comment on column x$io_by_thread_by_latency.processlist_id not supported: The PROCESSLIST.ID value for threads displayed in the INFORMATION_SCHEMA.PROCESSLIST table, or 0 for background threads. Also corresponds with the CONNECTION_ID() return value for the thread.

