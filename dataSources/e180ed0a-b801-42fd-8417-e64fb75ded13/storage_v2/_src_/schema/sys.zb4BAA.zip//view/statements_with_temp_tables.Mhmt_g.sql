create definer = `mariadb.sys`@localhost view statements_with_temp_tables as
select `sys`.`format_statement`(`performance_schema`.`events_statements_summary_by_digest`.`DIGEST_TEXT`)      AS `query`,
       `performance_schema`.`events_statements_summary_by_digest`.`SCHEMA_NAME`                                AS `db`,
       `performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`                                 AS `exec_count`,
       format_pico_time(`performance_schema`.`events_statements_summary_by_digest`.`SUM_TIMER_WAIT`)           AS `total_latency`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_CREATED_TMP_TABLES`                     AS `memory_tmp_tables`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_CREATED_TMP_DISK_TABLES`                AS `disk_tmp_tables`,
       round(ifnull(`performance_schema`.`events_statements_summary_by_digest`.`SUM_CREATED_TMP_TABLES` /
                    nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`, 0), 0),
             0)                                                                                                AS `avg_tmp_tables_per_query`,
       round(ifnull(`performance_schema`.`events_statements_summary_by_digest`.`SUM_CREATED_TMP_DISK_TABLES` /
                    nullif(`performance_schema`.`events_statements_summary_by_digest`.`SUM_CREATED_TMP_TABLES`, 0), 0) *
             100,
             0)                                                                                                AS `tmp_tables_to_disk_pct`,
       `performance_schema`.`events_statements_summary_by_digest`.`FIRST_SEEN`                                 AS `first_seen`,
       `performance_schema`.`events_statements_summary_by_digest`.`LAST_SEEN`                                  AS `last_seen`,
       `performance_schema`.`events_statements_summary_by_digest`.`DIGEST`                                     AS `digest`
from `performance_schema`.`events_statements_summary_by_digest`
where `performance_schema`.`events_statements_summary_by_digest`.`SUM_CREATED_TMP_TABLES` > 0
order by `performance_schema`.`events_statements_summary_by_digest`.`SUM_CREATED_TMP_DISK_TABLES` desc,
         `performance_schema`.`events_statements_summary_by_digest`.`SUM_CREATED_TMP_TABLES` desc;

-- comment on column statements_with_temp_tables.db not supported: Database name. Records are summarised together with DIGEST.

-- comment on column statements_with_temp_tables.exec_count not supported: Number of summarized events

-- comment on column statements_with_temp_tables.memory_tmp_tables not supported: Sum of the CREATED_TMP_TABLES column in the events_statements_current table.

-- comment on column statements_with_temp_tables.disk_tmp_tables not supported: Sum of the CREATED_TMP_DISK_TABLES column in the events_statements_current table.

-- comment on column statements_with_temp_tables.first_seen not supported: Time at which the digest was first seen.

-- comment on column statements_with_temp_tables.last_seen not supported: Time at which the digest was most recently seen.

-- comment on column statements_with_temp_tables.digest not supported: Performance Schema digest. Records are summarised together with SCHEMA NAME.

