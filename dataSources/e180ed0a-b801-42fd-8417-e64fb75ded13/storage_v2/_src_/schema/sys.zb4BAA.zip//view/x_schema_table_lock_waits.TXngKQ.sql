create definer = `mariadb.sys`@localhost view x$schema_table_lock_waits as
select `g`.`OBJECT_SCHEMA`                              AS `object_schema`,
       `g`.`OBJECT_NAME`                                AS `object_name`,
       `pt`.`THREAD_ID`                                 AS `waiting_thread_id`,
       `pt`.`PROCESSLIST_ID`                            AS `waiting_pid`,
       `sys`.`ps_thread_account`(`p`.`OWNER_THREAD_ID`) AS `waiting_account`,
       `p`.`LOCK_TYPE`                                  AS `waiting_lock_type`,
       `p`.`LOCK_DURATION`                              AS `waiting_lock_duration`,
       `pt`.`PROCESSLIST_INFO`                          AS `waiting_query`,
       `pt`.`PROCESSLIST_TIME`                          AS `waiting_query_secs`,
       `ps`.`ROWS_AFFECTED`                             AS `waiting_query_rows_affected`,
       `ps`.`ROWS_EXAMINED`                             AS `waiting_query_rows_examined`,
       `gt`.`THREAD_ID`                                 AS `blocking_thread_id`,
       `gt`.`PROCESSLIST_ID`                            AS `blocking_pid`,
       `sys`.`ps_thread_account`(`g`.`OWNER_THREAD_ID`) AS `blocking_account`,
       `g`.`LOCK_TYPE`                                  AS `blocking_lock_type`,
       `g`.`LOCK_DURATION`                              AS `blocking_lock_duration`,
       concat('KILL QUERY ', `gt`.`PROCESSLIST_ID`)     AS `sql_kill_blocking_query`,
       concat('KILL ', `gt`.`PROCESSLIST_ID`)           AS `sql_kill_blocking_connection`
from (((((`performance_schema`.`metadata_locks` `g` join `performance_schema`.`metadata_locks` `p`
          on (`g`.`OBJECT_TYPE` = `p`.`OBJECT_TYPE` and `g`.`OBJECT_SCHEMA` = `p`.`OBJECT_SCHEMA` and
              `g`.`OBJECT_NAME` = `p`.`OBJECT_NAME` and `g`.`LOCK_STATUS` = 'GRANTED' and
              `p`.`LOCK_STATUS` = 'PENDING')) join `performance_schema`.`threads` `gt`
         on (`g`.`OWNER_THREAD_ID` = `gt`.`THREAD_ID`)) join `performance_schema`.`threads` `pt`
        on (`p`.`OWNER_THREAD_ID` = `pt`.`THREAD_ID`)) left join `performance_schema`.`events_statements_current` `gs`
       on (`g`.`OWNER_THREAD_ID` = `gs`.`THREAD_ID`)) left join `performance_schema`.`events_statements_current` `ps`
      on (`p`.`OWNER_THREAD_ID` = `ps`.`THREAD_ID`))
where `g`.`OBJECT_TYPE` = 'TABLE';

-- comment on column x$schema_table_lock_waits.object_schema not supported: Object schema.

-- comment on column x$schema_table_lock_waits.object_name not supported: Object name.

-- comment on column x$schema_table_lock_waits.waiting_thread_id not supported: A unique thread identifier.

-- comment on column x$schema_table_lock_waits.waiting_pid not supported: The PROCESSLIST.ID value for threads displayed in the INFORMATION_SCHEMA.PROCESSLIST table, or 0 for background threads. Also corresponds with the CONNECTION_ID() return value for the thread.

-- comment on column x$schema_table_lock_waits.waiting_lock_type not supported: Lock type. One of BACKUP_FTWRL1, BACKUP_START, BACKUP_TRANS_DML, EXCLUSIVE, INTENTION_EXCLUSIVE, SHARED, SHARED_HIGH_PRIO, SHARED_NO_READ_WRITE, SHARED_NO_WRITE, SHARED_READ, SHARED_UPGRADABLE or SHARED_WRITE.

-- comment on column x$schema_table_lock_waits.waiting_lock_duration not supported: Lock duration. One of EXPLICIT (locks released by explicit action, for example a global lock acquired with FLUSH TABLES WITH READ LOCK) , STATEMENT (locks implicitly released at statement end) or TRANSACTION (locks implicitly released at transaction end).

-- comment on column x$schema_table_lock_waits.waiting_query not supported: Statement being executed by the thread, or NULL if a statement is not being executed. If a statement results in calling other statements, such as for a stored procedure, the innermost statement from the stored procedure is shown here.

-- comment on column x$schema_table_lock_waits.waiting_query_secs not supported: Time in seconds the thread has been in its current state.

-- comment on column x$schema_table_lock_waits.waiting_query_rows_affected not supported: Number of rows affected the statement affected.

-- comment on column x$schema_table_lock_waits.waiting_query_rows_examined not supported: Number of rows read during the statement's execution.

-- comment on column x$schema_table_lock_waits.blocking_thread_id not supported: A unique thread identifier.

-- comment on column x$schema_table_lock_waits.blocking_pid not supported: The PROCESSLIST.ID value for threads displayed in the INFORMATION_SCHEMA.PROCESSLIST table, or 0 for background threads. Also corresponds with the CONNECTION_ID() return value for the thread.

-- comment on column x$schema_table_lock_waits.blocking_lock_type not supported: Lock type. One of BACKUP_FTWRL1, BACKUP_START, BACKUP_TRANS_DML, EXCLUSIVE, INTENTION_EXCLUSIVE, SHARED, SHARED_HIGH_PRIO, SHARED_NO_READ_WRITE, SHARED_NO_WRITE, SHARED_READ, SHARED_UPGRADABLE or SHARED_WRITE.

-- comment on column x$schema_table_lock_waits.blocking_lock_duration not supported: Lock duration. One of EXPLICIT (locks released by explicit action, for example a global lock acquired with FLUSH TABLES WITH READ LOCK) , STATEMENT (locks implicitly released at statement end) or TRANSACTION (locks implicitly released at transaction end).

