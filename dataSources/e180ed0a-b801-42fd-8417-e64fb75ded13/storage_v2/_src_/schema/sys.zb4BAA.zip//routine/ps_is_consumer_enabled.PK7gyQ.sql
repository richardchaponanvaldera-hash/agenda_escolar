create
    definer = `mariadb.sys`@localhost function ps_is_consumer_enabled(in_consumer varchar(64)) returns enum ('YES', 'NO')
    comment '
             Description
             Determines whether a consumer is enabled (taking the consumer hierarchy into consideration)
             within the Performance Schema.
             Parameters
             in_consumer VARCHAR(64):
               The name of the consumer to check.
             Returns
             ENUM(''YES'', ''NO'')
             Example
             mysql> SELECT sys.ps_is_consumer_enabled(''events_stages_history'');
             +-----------------------------------------------------+
             | sys.ps_is_consumer_enabled(''events_stages_history'') |
             +-----------------------------------------------------+
             | NO                                                  |
             +-----------------------------------------------------+
             1 row in set (0.00 sec)
            '
    deterministic
    sql security invoker
    reads sql data
BEGIN
    RETURN (
        SELECT (CASE
                   WHEN c.NAME = 'global_instrumentation' THEN c.ENABLED
                   WHEN c.NAME = 'thread_instrumentation' THEN IF(cg.ENABLED = 'YES' AND c.ENABLED = 'YES', 'YES', 'NO')
                   WHEN c.NAME LIKE '%\_digest'           THEN IF(cg.ENABLED = 'YES' AND c.ENABLED = 'YES', 'YES', 'NO')
                   WHEN c.NAME LIKE '%\_current'          THEN IF(cg.ENABLED = 'YES' AND ct.ENABLED = 'YES' AND c.ENABLED = 'YES', 'YES', 'NO')
                   ELSE IF(cg.ENABLED = 'YES' AND ct.ENABLED = 'YES' AND c.ENABLED = 'YES'
                           AND ( SELECT cc.ENABLED FROM performance_schema.setup_consumers cc WHERE NAME = CONCAT(SUBSTRING_INDEX(c.NAME, '_', 2), '_current')
                               ) = 'YES', 'YES', 'NO')
                END) AS IsEnabled
          FROM performance_schema.setup_consumers c
               INNER JOIN performance_schema.setup_consumers cg
               INNER JOIN performance_schema.setup_consumers ct
         WHERE cg.NAME       = 'global_instrumentation'
               AND ct.NAME   = 'thread_instrumentation'
               AND c.NAME    = in_consumer
       );
END;

