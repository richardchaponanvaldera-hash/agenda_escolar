create
    definer = `mariadb.sys`@localhost function ps_is_instrument_default_timed(in_instrument varchar(128)) returns enum ('YES', 'NO')
    comment '
             Description
             Returns whether an instrument is timed by default in this version of MySQL.
             Parameters
             in_instrument VARCHAR(128):
               The instrument to check.
             Returns
             ENUM(''YES'', ''NO'')
             Example
             mysql> SELECT sys.ps_is_instrument_default_timed(''statement/sql/select'');
             +------------------------------------------------------------+
             | sys.ps_is_instrument_default_timed(''statement/sql/select'') |
             +------------------------------------------------------------+
             | YES                                                        |
             +------------------------------------------------------------+
             1 row in set (0.00 sec)
            '
    deterministic
    sql security invoker
    reads sql data
BEGIN
    DECLARE v_timed ENUM('YES', 'NO');
    SET v_timed = IF(in_instrument LIKE 'wait/io/file/%'
                        OR in_instrument LIKE 'wait/io/table/%'
                        OR in_instrument LIKE 'statement/%'
                        OR in_instrument IN ('wait/lock/table/sql/handler', 'idle')
               
                      ,
                       'YES',
                       'NO'
                    );
    RETURN v_timed;
END;

